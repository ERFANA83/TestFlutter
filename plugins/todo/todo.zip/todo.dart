import 'package:flutter/material.dart';
import 'plugin_interface.dart';

class TodoPlugin implements AppPlugin {
  @override
  String get name => "Todo List";

  @override
  Widget get icon => Icon(Icons.list);

  @override
  Widget build() => TodoWidget();
}

class TodoWidget extends StatefulWidget {
  @override
  _TodoWidgetState createState() => _TodoWidgetState();
}

class _TodoWidgetState extends State<TodoWidget> {
  final List<String> _items = [];
  final TextEditingController _controller = TextEditingController();

  void _addItem() {
    if (_controller.text.trim().isNotEmpty) {
      setState(() {
        _items.add(_controller.text.trim());
        _controller.clear();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextField(controller: _controller, decoration: InputDecoration(labelText: 'New Task')),
        ElevatedButton(onPressed: _addItem, child: Text("Add")),
        ..._items.map((e) => ListTile(title: Text(e))),
      ],
    );
  }
}

