import 'package:flutter/material.dart';
import 'plugin_interface.dart';
import 'package:math_expressions/math_expressions.dart';

class CalculatorPlugin implements AppPlugin {
  @override
  String get name => "Calculator";

  @override
  Widget get icon => Icon(Icons.calculate);

  @override
  Widget build() => CalculatorWidget();
}

class CalculatorWidget extends StatefulWidget {
  @override
  _CalculatorWidgetState createState() => _CalculatorWidgetState();
}

class _CalculatorWidgetState extends State<CalculatorWidget> {
  String _expression = "";
  String _result = "";

  void _append(String value) {
    setState(() => _expression += value);
  }

  void _clear() {
    setState(() {
      _expression = "";
      _result = "";
    });
  }

  void _calculate() {
    try {
      Parser p = Parser();
      Expression exp = p.parse(_expression.replaceAll('×', '*').replaceAll('÷', '/'));
      ContextModel cm = ContextModel();
      double eval = exp.evaluate(EvaluationType.REAL, cm);
      setState(() => _result = eval.toString());
    } catch (e) {
      setState(() => _result = "خطا در محاسبه");
    }
  }

  @override
  Widget build(BuildContext context) {
    final buttons = [
      '7', '8', '9', '÷',
      '4', '5', '6', '×',
      '1', '2', '3', '-',
      '0', '.', '=', '+',
      'C'
    ];

    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(16),
          alignment: Alignment.centerRight,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(_expression, style: TextStyle(fontSize: 24, color: Colors.black87)),
              SizedBox(height: 8),
              Text(_result, style: TextStyle(fontSize: 32, color: Colors.blue)),
            ],
          ),
        ),
        Divider(),
        Expanded(
          child: GridView.builder(
            itemCount: buttons.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4),
            itemBuilder: (context, index) {
              final btn = buttons[index];
              return ElevatedButton(
                onPressed: () {
                  if (btn == "C") _clear();
                  else if (btn == "=") _calculate();
                  else _append(btn);
                },
                child: Text(btn, style: TextStyle(fontSize: 20)),
              );
            },
          ),
        ),
      ],
    );
  }
}